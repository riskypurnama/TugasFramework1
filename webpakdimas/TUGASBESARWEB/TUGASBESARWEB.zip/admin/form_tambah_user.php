<html>
<form action="tambah_user.php" method="post">
    
    <table>
		
        <tr>
            <td><b>Username</b></td>
            <td><input type="text" name="username" /></td>
        </tr>
        <tr>
            <td><b>Password </b></td>
            <td><input type="password" name="password" /></td>
        </tr>
        
        <tr>
               <td><input type="submit" value="Tambah User"></td>
         </tr>    
    </table>  
    
</form>

</html>



